package com.tecsup.RegisterReserva;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegisterReservaApplicationTests {

	@Test
	void contextLoads() {
	}

}
